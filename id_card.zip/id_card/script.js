function previewId(){
    let leftPanel= document.querySelector(".left-panel");
    let generateCard= document.querySelector("#generateCard");
    let PreviewCard= document.querySelector("#PreviewCard");
    leftPanel.style.display="none";
    generateCard.style.display="block"; 
    PreviewCard.style.display="none"; 

 }
 document.addEventListener("DOMContentLoaded", function() {
     var employeeDetails = [];

     function updateLivePreview() {
         var name = document.getElementById("name").value || "N/A";
         var collegeName = document.getElementById("collegeName").value;
         var studentId = document.getElementById("studentId").value;
         var course = document.getElementById("course").value;
         var photo = document.getElementById("photo").files[0];
         var photoPreview = document.getElementById("idCardPhoto");
         var textColor = document.getElementById("text-color").value || "#000000";
         var fontFamily = document.getElementById("font-family").value || "Arial";
         var idCardName = document.getElementById("idCardName");
         var idCardStudentId = document.getElementById("idCardStudentId");
         var idCardCourse = document.getElementById("idCardCourse");
         var namePositionTopToBottom = document.getElementById("namePositionTopToBottom").value;
         var namePositionLeftToRight = document.getElementById("namePositionLeftToRight").value;
         var idPositionTopToBottom = document.getElementById("idPositionTopToBottom").value;
         var idPositionLeftToRight = document.getElementById("idPositionLeftToRight").value;
         var coursePositionTopToBottom = document.getElementById("coursePositionTopToBottom").value;
         var coursePositionLeftToRight = document.getElementById("coursePositionLeftToRight").value;

         document.getElementById('college-name').innerText = collegeName;
         document.getElementById('idCardName').innerText = name;
         document.getElementById('idCardStudentId').innerText = `Student ID: ${studentId}`;
         document.getElementById('idCardCourse').innerText = `Course: ${course}`;

         if (idCardName) {
             idCardName.textContent = name;
             idCardName.style.color = textColor;
             idCardName.style.fontFamily = fontFamily;
             idCardName.style.top = `${namePositionTopToBottom}px`;
             idCardName.style.left = `${namePositionLeftToRight}px`;
         }
         if (idCardStudentId) {
             idCardStudentId.textContent = studentId;
             idCardStudentId.style.color = textColor;
             idCardStudentId.style.fontFamily = fontFamily;
             idCardStudentId.style.top = `${idPositionTopToBottom}px`;
             idCardStudentId.style.left = `${idPositionLeftToRight}px`;
         }
         if (idCardCourse) {
             idCardCourse.textContent = course;
             idCardCourse.style.color = textColor;
             idCardCourse.style.fontFamily = fontFamily;
             idCardCourse.style.top = `${coursePositionTopToBottom}px`;
             idCardCourse.style.left = `${coursePositionLeftToRight}px`;
         }

         if (photo) {
             var reader = new FileReader();
             reader.onload = function(e) {
                 photoPreview.style.backgroundImage = `url(${e.target.result})`;
             };
             reader.readAsDataURL(photo);
         } else {
             photoPreview.style.backgroundImage = 'none';
         }
     }
     

     document.getElementById("name").addEventListener("input", updateLivePreview);
     document.getElementById("collegeName").addEventListener("input", updateLivePreview);
     document.getElementById("studentId").addEventListener("input", updateLivePreview);
     document.getElementById("course").addEventListener("input", updateLivePreview);
     document.getElementById("photo").addEventListener("change", updateLivePreview);
     document.getElementById("text-color").addEventListener("input", updateLivePreview);
     document.getElementById("font-family").addEventListener("input", updateLivePreview);
     document.getElementById("namePositionTopToBottom").addEventListener("input", updateLivePreview);
     document.getElementById("namePositionLeftToRight").addEventListener("input", updateLivePreview);
     document.getElementById("idPositionTopToBottom").addEventListener("input", updateLivePreview);
     document.getElementById("idPositionLeftToRight").addEventListener("input", updateLivePreview);
     document.getElementById("coursePositionTopToBottom").addEventListener("input", updateLivePreview);
     document.getElementById("coursePositionLeftToRight").addEventListener("input", updateLivePreview);

     document.getElementById("idCardForm").addEventListener("submit", function(event) {
         event.preventDefault();
         var name = document.getElementById("name").value;
         var collegeName = document.getElementById("collegeName").value;
         var studentId = document.getElementById("studentId").value;
         var course = document.getElementById("course").value;
         var photo = document.getElementById("photo").files[0];

         var employee = {
             name: name,
             collegeName: collegeName,
             studentId: studentId,
             course: course,
             photo: photo
         };

         employeeDetails.push(employee);

         document.getElementById("name").value = "";
         document.getElementById("collegeName").value = "";
         document.getElementById("studentId").value = "";
         document.getElementById("course").value = "";
         document.getElementById("photo").value = "";

         clearLivePreview();
     });

     function clearLivePreview() {
         var photoPreview = document.getElementById("idCardPhoto");
     }
 });
 function generatePDF() {
     var element = document.getElementById('idCardContent');
   

     var opt = {
         margin: 0,
         filename: 'myfile.pdf',
         image: { type: 'jpeg', quality: 1 },
         html2canvas: { scale: 1 },
         jsPDF: { unit: 'in', format: [4.6, 3.01], orientation: 'landscape', precision: '12' } 
     };

     html2pdf().set(opt).from(element).save();
 }
 function closeTemplate(){
    document.getElementById('template').style.display='none';
 }

 function myFunction1(value){
   let idCardContent=document.getElementById('idCardContent');
   idCardContent.style.backgroundImage='url(https://e1.pxfuel.com/desktop-wallpaper/763/623/desktop-wallpaper-best-backgrounds-for-id-card-id-card.jpg)';
   var leftPanel=document.getElementById("left-panel");
    leftPanel.style.display="block";
    closeTemplate();

 }
 function myFunction2(){
   let idCardContent=document.getElementById('idCardContent');
   idCardContent.style.backgroundImage='url(https://media.istockphoto.com/id/1173905761/video/gray-abstract-minimal-motion-backgrounds-loopable-elements-4k-resolution.jpg?s=640x640&k=20&c=SufjBIhB791a7uD3FtTrIkAfXaGhgfFqra0fdzuAuLw=)';
   var leftPanel=document.getElementById("left-panel");
    leftPanel.style.display="block";
    closeTemplate();
 }
 function myFunction3(){
   let idCardContent=document.getElementById('idCardContent');
   idCardContent.style.backgroundImage='url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR22qLf7lYn98nZSKZjm-vAlg_QkqtHREYIBQp_P2_KOQ&s)';
   var leftPanel=document.getElementById("left-panel");
    leftPanel.style.display="block";
    closeTemplate();
 }
 function myFunction4(){
    let idCardContent=document.getElementById('idCardContent');
    idCardContent.style.backgroundImage='url(https://media.istockphoto.com/id/1193530751/vector/pink-blue-teal-watermark-pattern-line-art-design-subtle-zigzag-curves-vector-abstract.jpg?s=612x612&w=0&k=20&c=-Mvuda9Owtk9KToqMgXxvQcytW9guG0sLwKgzNjmn58=)';
    var leftPanel=document.getElementById("left-panel");
     leftPanel.style.display="block";
     closeTemplate();
  }
  function myFunction5(){
    let idCardContent=document.getElementById('idCardContent');
    idCardContent.style.backgroundImage='url(https://media.istockphoto.com/id/1143980343/photo/gold-and-silver-fireworks-and-bokeh-in-new-year-eve-and-copy-space-abstract-background-holiday.webp?b=1&s=170667a&w=0&k=20&c=2BRuYsVu-Q1GGX0Sxn_Igyfq6ut4CZbFg_oSi5x--Hg=)';
    var leftPanel=document.getElementById("left-panel");
     leftPanel.style.display="block";
     closeTemplate();
  }